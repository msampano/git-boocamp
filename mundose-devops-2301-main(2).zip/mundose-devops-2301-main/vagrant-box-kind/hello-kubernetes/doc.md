roxsross12/hello-kubernetes:1.10
hello-kubernetes-first
        ports:
        - containerPort: 8080
        env:
        - name: MESSAGE
          value: Hello from the first deployment!

hello-kubernetes-second
        ports:
        - containerPort: 8080
        env:
        - name: MESSAGE
          value: Hello from the second deployment!
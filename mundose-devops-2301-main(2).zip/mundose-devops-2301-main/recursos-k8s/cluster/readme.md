aws eks update-kubeconfig --region us-east-1 --name test-cluster
export KUBECONFIG=/Users/rossanasuarez/.kube/eksctl/clusters/tcss702-eks

.aws/config
[Default]
region=us-east-1

.aws/credentials
[default]
aws_access_key_id=AKIAZQLGZZYIAOGXVM7Z
aws_secret_access_key=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
region=us-east-1

HA us-east-1
   us-east-2

ns propio -> apellidoInicialnombre /Inicialnombreapellido
          ->rsuarez


          export KUBECONFIG=/Users/rossanasuarez/.kube/eksctl/clusters/tcss702-eks
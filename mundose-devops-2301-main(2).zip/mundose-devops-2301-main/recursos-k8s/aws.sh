#!/bin/bash
export AWS_ACCESS_KEY_ID=AKIAVP5EAAGLAIU3VGMN
export AWS_SECRET_ACCESS_KEY=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
export AWS_DEFAULT_REGION=us-east-1

echo "check"
sleep 0.5

aws sts get-caller-identity
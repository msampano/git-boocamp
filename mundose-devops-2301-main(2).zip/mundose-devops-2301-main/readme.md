# Minikube Vagrant

Minikube usando virtualbox. Sin tener que instalar ningún binario en el host.

El clúster de Kubernetes se expondrá al host mediante una red privada.

```
+------------------------------------------------------+
| Host (private_network_ip)                            |
|     +-----------------------------------+            |
|     | Vagrant box                       |            |
|     |    +------------------------------+            |
|     |    | Minikube                     |            |
|     |    |   +--------------------------+            |
|     |    |   | Pods/Services/foo...     |            |
|     |    |   |                          |            |
|     |    |   |                          | <--+curl   |
|     |    |   |                          |     browser|
|     |    |   |                          |            |
|     |    |   |                          |            |
|     |    |   |                          |            |
|     |    |   |                          |            |
+-----+----+---+--------------------------+------------+
```


## Pre-requisites

Vagrant (https://www.vagrantup.com/docs/installation/)



## Options

Edita las variables en el Vagrantfile


| Option              | Description   | Default                 |
| -------------       | ------------- | -------------           |
| KUBERNETES_VERSION  | Kubernetes version to install           | 1.26
| CONTAINER_RUNTIME   | Runtime to use (containerd, docker)     | containerd
| CLUSTER_NODES       | Number of nodes to setup                | 1
| PRIVATE_NETWORK_IP  | Prefered private network ip (from host) | 172.20.128.2

# Usage

### Install

```
vagrant up
```

### Suspend / resume

```
vagrant suspend
vagrant resume
```

### Manage kubernetes cluster

```
vagrant ssh
kubectl get pods -A
```

### Access to kubernetes dashboard from host
```
vagrant ssh -c 'bash -ci dashboard'

http://PRIVATE_NETWORK_IP:9999/api/v1/namespaces/kubernetes-dashboard/services/http:kubernetes-dashboard:/proxy/#/workloads?namespace=default
```

### Access to exposed services from host
```
vagrant ssh -c 'bash -ci tunnel'

curl PRIVATE_NETWORK_IP:80/exposed-svc
```

# Example

This example will create an ingress (foo-ingress) listening on port 80 and routing to the corresponding service (foo-service) targeting pod (foo-app) on port 8080.

```
vagrant ssh

kubectl apply -f ingress.yaml

```

From the host

```
vagrant ssh -c 'bash -ci tunnel'

curl http://172.20.128.2/foo

============================================
Request served by foo-app

HTTP/1.1 GET /foo

Host: 172.20.128.2
Accept: */*
User-Agent: curl/7.58.0
X-Forwarded-For: 10.244.0.1
X-Forwarded-Host: 172.20.128.2
X-Forwarded-Port: 80
```

```
kubectl port-forward --address 0.0.0.0 pod/foo-app 7080:80
```